<div class="card mb-2">
    <div class="card-body">
        <div class="d-flex justify-content-center">
            <div class="d-flex flex-column justify-content-center">
                <a href="#" class="btn btn-primary mb-2">Кнопка виджета (бесполезная)</a>
                <a href="https://vk.com/reenekt" target="_blank" class="btn btn-outline-primary">Автор системы плагинов</a>
            </div>
        </div>
    </div>
</div>
